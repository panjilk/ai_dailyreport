"""Structured research/release sources and source-only English extracts."""
import json
import re
from datetime import datetime
from email.utils import parsedate_to_datetime
from html import unescape

from bs4 import BeautifulSoup
import feedparser
from .models import MODEL_NAMES


def english_topic(title, abstract):
    text = str(title or '') + ' ' + str(abstract or '')
    return bool(MODEL_NAMES.search(text) or re.search(r'large language model|\bLLMs?\b|foundation model|language model|multimodal|vision.language|reasoning|benchmark|evaluation', text, re.I))


def english_ai_related(title, text):
    """Broad AI filter for mixed-topic English technology feeds."""
    value = str(title or '') + ' ' + str(text or '')
    return bool(MODEL_NAMES.search(value) or re.search(
        r'\bartificial intelligence\b|\bAI\b|\bmachine learning\b|\bdeep learning\b|'
        r'\bneural networks?\b|\bLLMs?\b|\blanguage models?\b|\bgenerative AI\b|'
        r'\bAI agents?\b|\btransformers?\b|\bdiffusion models?\b|\bmodel inference\b',
        value, re.I))


def english_blog_candidate(title, text):
    """Keep AI posts whose headline is meaningful without opening the article."""
    title = re.sub(r'\s+', ' ', str(title or '')).strip()
    if not english_ai_related(title, text):
        return False
    if english_ai_related(title, ''):
        return True
    if re.match(r'^(?:quoting|note on|notes? on|link(?: blog)?|quick note)\b', title, re.I):
        return False
    return len(re.findall(r"[A-Za-z0-9][A-Za-z0-9'’-]*", title)) >= 4


def normalized_feed_date(value):
    """Return an aware ISO timestamp for either Atom/ISO or RSS/RFC 822 dates."""
    text = str(value or '').strip()
    if not text:
        raise ValueError('英文技术博客条目缺少发布日期')
    try:
        moment = datetime.fromisoformat(text.replace('Z', '+00:00'))
    except ValueError:
        moment = parsedate_to_datetime(text)
    if moment.tzinfo is None or moment.utcoffset() is None:
        raise ValueError('英文技术博客发布日期缺少时区')
    return moment.isoformat()


def source_rows(source, content):
    kind = source['type']
    if kind == 'hf_papers':
        entries = json.loads(content)
        if not isinstance(entries, list):
            raise ValueError('Hugging Face 未返回论文列表')
        for item in entries[:500]:
            paper = item.get('paper', {})
            identifier = paper.get('id', '')
            if not re.fullmatch(r'\d{4}\.\d{4,5}', identifier):
                continue
            # Daily selection is discovery, never the publication date.
            yield dict(title=paper.get('title', ''), published=paper.get('publishedAt'),
                       source_url='https://arxiv.org/abs/' + identifier,
                       abstract=paper.get('summary', ''), content_kind='paper')
    elif kind == 'github_releases':
        entries = json.loads(content)
        if not isinstance(entries, list):
            raise ValueError('GitHub 未返回版本列表')
        for item in entries[:100]:
            if item.get('draft') or item.get('prerelease'):
                continue
            yield dict(title=source['name'] + ' ' + (item.get('tag_name') or item.get('name', '')),
                       published=item.get('published_at'), event_date=item.get('published_at'),
                       event_date_evidence='GitHub release published_at: ' + str(item.get('published_at')),
                       source_url=item.get('html_url', ''), abstract=item.get('body') or '', content_kind='release')
    elif kind == 'arxiv':
        feed = feedparser.parse(content)
        if not feed.version:
            raise ValueError('arXiv 未返回 RSS/Atom')
        for item in feed.entries[:500]:
            if item.get('arxiv_announce_type') not in (None, 'new'):
                continue
            yield dict(title=item.get('title', ''), published=item.get('published'),
                       source_url=item.get('link', ''),
                       abstract=item.get('summary', '').split('Abstract:', 1)[-1].strip(), content_kind='paper')
    elif kind == 'english_rss':
        feed = feedparser.parse(content)
        if not feed.version:
            raise ValueError('英文技术博客未返回 RSS/Atom')
        for item in feed.entries[:500]:
            published = normalized_feed_date(item.get('published') or item.get('updated'))
            content_blocks = item.get('content') or []
            article = content_blocks[0].get('value', '') if content_blocks else item.get('summary', '')
            title = unescape(re.sub(r'<[^>]+>', ' ', str(item.get('title', ''))))
            title = re.sub(r'\s+', ' ', title).strip()
            yield dict(title=title,
                       published=published, event_date=published,
                       event_date_evidence='RSS/Atom published: ' + str(published),
                       source_url=item.get('link', ''), abstract=article,
                       content_kind='article')


def paper_details(content):
    soup = BeautifulSoup(content, 'html.parser')
    history = soup.select_one('.submission-history')
    match = re.search(r'\[v1\]\s*([^\n(]+(?:UTC|GMT))', history.get_text(' ', strip=True) if history else '')
    if not match:
        raise ValueError('论文缺少可核实的首次提交时间，不能使用推荐或修订日期')
    timestamp = parsedate_to_datetime(match[1]).isoformat()
    abstract = soup.select_one('meta[name="citation_abstract"]')
    text = abstract.get('content', '') if abstract else ''
    if not text:
        block = soup.select_one('blockquote.abstract')
        text = block.get_text(' ', strip=True) if block else ''
    if not text:
        raise ValueError('论文缺少摘要')
    return text, dict(event_date=timestamp, event_date_evidence='arXiv [v1] ' + match[1])


def english_summary(text, kind):
    """Keep whole statements, attribution and caveats; do not invent translations."""
    if not isinstance(text, (str, bytes)):
        raise ValueError('英文正文不足以抽取摘要')
    text = BeautifulSoup(text, 'html.parser').get_text(' ', strip=True)
    text = re.sub(r'!\[[^\]]*\]\([^)]*\)', '', text)
    text = re.sub(r'\[([^\]]+)\]\([^)]*\)', r'\1', text)
    text = re.sub(r'[`#*]', '', text)
    sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+(?=[A-Z])|\n+', text)
                 if len(s.strip()) >= 30 and re.search(r'[A-Za-z]', s)]
    if not sentences:
        raise ValueError('英文正文不足以抽取摘要')
    caveats = [s for s in sentences if re.search(r'\b(?:however|limitation|limited|only|cannot|not|bottleneck|failure|may|suggest)\b', s, re.I)]
    selected = [sentences[0]]
    result = next((s for s in sentences[1:] if re.search(r'\b(?:achiev|improv|result|outperform|benchmark|evaluat|support)\w*', s, re.I)), None)
    if result:
        selected.append(result)
    selected = list(dict.fromkeys(selected + caveats))
    if any(re.search(r'…|\.{3}', sentence) for sentence in selected):
        raise ValueError('英文 Feed 摘要包含省略号或截断文字')
    # Keep every detected qualification; fail rather than silently drop one.
    if len(selected) > 3 or sum(map(len, selected)) > 1100:
        raise ValueError('英文摘要与必要限定超过单页容量，需人工精简')
    notice = ('论文摘要摘录，结果为作者报告；未核实同行评审或独立复测。' if kind == 'paper'
              else '官方版本说明摘录；工具更新不等于模型本身发布。' if kind == 'release'
              else '英文技术博客摘录；观点与判断属于原作者，未经独立复核。')
    return [notice] + selected
